const path = require("path");
const { composePlugins, withNx } = require("@nx/webpack");
const { withReact } = require("@nx/react");
const MonacoWebpackPlugin = require("monaco-editor-webpack-plugin");

module.exports = composePlugins(
  withNx(),
  withReact(),
  (config, { options, context }) => {
    // NOTE: chevrotain used by hyperformula doesn't provide sourcemap and it show warning in the console, so we ignore this.
    config.module.rules[0].exclude = /chevrotain/;
    return {
      ...config,
      plugins: [...config.plugins, new MonacoWebpackPlugin()],
      resolve: {
        ...config.resolve,
        alias: {
          react: path.resolve("./node_modules/react"),
          // Force webpack to resolve monaco-editor directly from root node_modules
          // instead of through @ingestro/importer-react
          "monaco-editor": path.resolve("./node_modules/monaco-editor"),
        },
        // Ensure webpack prefers resolving from root node_modules first
        modules: [
          path.resolve("./node_modules"),
          ...(config.resolve.modules || ["node_modules"]),
        ],
      },
    };
  }
);
